---
name: interior-statutory-compliance
description: >
  Occupancy, accessibility, and general interior code compliance reviews.
  Use for statutory gaps, submission touchpoints, and AHJ-dependent checks.
disable-model-invocation: true
---

# interior-statutory-compliance

For HK application of overseas textbook examples, read [Hong Kong adaptation](../../references/ching-hk-adaptation.md): accessibility/legal status, fire/stairs/barriers, daylight, services, energy, IAQ and certification. Confirm scope and edition before adopting a dimension or performance claim.

For old-flat lightwells, former balcony enclosures, irregular beams/walls, damp-wall linings or water-heater feasibility, load [old-flat survey risks](references/old-flat-survey-risks.md). Check approved records and professional assessment before altering or concealing uncertain conditions.

For detailed egress/fire strategy, use `interior-fire-life-safety` instead.  
For physical service conflicts, use `interior-mep-clash-detection` instead.

## When to Use This Skill

| Question type | This skill | Use instead |
|---------------|------------|-------------|
| Occupancy, accessibility, code gap list | `interior-statutory-compliance` | — |
| Travel distance / exit capacity detail | — | `interior-fire-life-safety` |
| HK pre-start insurance/permits (industry) | This skill + HKEDCA ref | `interior-site-supervision` for execution |
| 士波令 / 露台玻璃 / MIC / 居屋拆牆 / 釘契 | This skill + `references/structural-and-hos-alerts.md` | Halt per `compliance.md` if AP/RSE or HA approval is missing |

## Purpose

For premises feasibility, restaurant/care-home licensing, adaptive reuse, heritage or approval layers, read [hkrida-licensing-adaptive-reuse.md](references/hkrida-licensing-adaptive-reuse.md). Classify actual works against current official guidance; historical examples do not authorize construction.
Use for statutory checks covering occupancy load, accessibility, and general interior code compliance.

## Core Outputs
- Compliance gap list with severity.
- Occupancy and fixture assumptions used.
- Required approval touchpoints and submission notes.

## Reference Table: Compliance Review Layers
| Layer | Typical Scope |
|---|---|
| Life safety | Egress, travel distance, exits, alarm/sprinkler interfaces |
| Accessibility | Clear widths, turning circles, sanitary provisions |
| Use/occupancy | Occupant load, function classification, capacity limits |
| Documentation | Drawing annotations, schedules, approval records |

## Decision Rules
1. Establish the governing jurisdiction, document status and project applicability first. Reconcile applicable local requirements with the responsible professional/AHJ; do not automatically substitute a stricter-looking overseas or advisory value for HK law. Record any approved variation.
2. Separate assumed values from confirmed values.
3. Route detail-level physical conflicts to `interior-mep-clash-detection`.
4. Spalling, balcony barriers, and HOS/MIC wall removal: load `references/structural-and-hos-alerts.md`. Do not diagnose reinforcement, self-classify minor works, or authorize the work. Halt per `compliance.md`.
5. A raised finish/platform beside a barrier changes the review even when anchors are untouched. Read `interior-interface-detailing`; record the relevant finished/step-on datum, climbability, added load, waterproofing/drainage and AP/RSE assessment needs. Include estate/management consent and the applicable statutory approval route as separate unresolved checks; management consent does not replace statutory approval.

## HK Local Practice (HKEDCA)

> HKEDCA documents **industry pre-start practice** — not AHJ approval.

### Reference Table: HK Pre-Start (from 清拆 + safety appendix)
| Item | HKEDCA / practice |
|---|---|
| Contractor insurance | Before works |
| Estate renovation permit | Management office |
| Scaffold | Permitted + LD safety rules |
| Gas hob removal | Registered gas contractor |
| Fire alarm | 掛牌 before fire-related works |

### Reference Table: HKEDCA vs Statutory
| Topic | HKEDCA | Confirm with AHJ |
|---|---|---|
| Renovation permit | Estate rules | BD if structural/window statutory |
| Electrical | Trade guide | EMSD |
| Plumbing | Trade guide | WSD if applicable |
| Working at height | Safety appendix | LD |

### HKEDCA decision rules
1. Never state “compliant with HKEDCA” equals legally approved.
2. Output AHJ checklist when statutory trigger uncertain.
3. Gas, scaffold, and alarm isolate are stop-work items if missing.

## HKEDCA Source Pointers
| File | Load when |
|---|---|
| `references/hkedca-preconstruction-compliance.md` | Pre-start, permits, insurance |
| [`references/structural-and-hos-alerts.md`](references/structural-and-hos-alerts.md) | Spalling, balcony glass fixings, MIC/HOS walls, dated official Joint Office procedures; recheck current notices |

### HKRG cross-reference

- Client duties before start: 保留清單, gas isolation, estate deposits (`HKRG §裝修需知/1.3`, `§1.1` items 8–9) — see `interior-site-supervision/references/hkrg-renovation-essentials-trades.md`.
- HKRG is **not** AHJ approval; clause 5 insurance waiver risk in HKRG quotation — pair with statutory insurance requirements.

## Region-Switch Notes (HK / Mainland China)
- Hong Kong mode: combine BO/FSD/BD/EMSD/WSD/LD with HKEDCA pre-start checklist (`§清拆/1`, `§附錄：安全建議`).
- Mainland mode: apply PRC code and local implementation standards by city/province.
- Always state the governing authority explicitly; if unknown, output jurisdiction checklist first.

## Reference Table: Typology Compliance Emphasis
| Typology | Statutory Emphasis |
|---|---|
| Residential | Means of escape, sanitary/accessibility minimums |
| Workplace | Occupant density, accessible route continuity, toilet ratios |
| Retail | Crowd load, frontage egress distribution, signage obligations |
| Hospitality | Public assembly interfaces and back-of-house separation |

## Auto-Chain Directives (Deterministic Schema)
| Trigger | Chain | Output format |
|---|---|---|
| Egress or fire-system implication is identified | `interior-fire-life-safety` | `RISK STATEMENT -> FIRE-LIFE-SAFETY CHECKLIST -> REQUIRED ACTIONS` |
| Clearance/access practicality needs validation | `interior-anthropometrics-ergonomics` | `DIMENSION CHECKS -> USER IMPACT -> ADJUSTMENT RECOMMENDATIONS` |
| Compliance notes must flow into tender docs | `interior-tendering-qa` | `TENDER INSERT LIST -> DRAWING TAGS -> SPEC ADDENDA NOTES` |

## Parent references

Load from parent references/ when needed (one hop):

* [compliance.md](../../references/compliance.md) — non-negotiable rules
* [domain_terms.json](../../references/domain_terms.json) — vocabulary
* [deliverables.md](../../references/templates/deliverables.md) — output catalog



For retained appliances, shower controls/screens, smart sockets, drainage or cabinet lighting, read [deco-fixtures-and-retained-services](../../references/deco-fixtures-and-retained-services.md).
