# Finish evidence and maintenance decisions

Sources: DECO-TV batch 2; [per-file coverage and archives](../../Reference/DECO-TV-BATCH2-COVERAGE-2026-11-07.md). Field demonstrations motivate the checks below; they do not certify materials or supply missing visual instructions.

## Feature walls and refurbishment options

Sources: `eE1Jt65_MOs`, `JpgsiEAeIEw`, `O8G_etfR84o`, `iWEnW8ZANlw`, `of_3Nc_Q4Bs`.

- Compare conventional paint/stencils, artist-applied murals, printed/textured wallcoverings and feature tiles against the concept before adding premium materials. Approve artwork scale/crop, seam/repeat, colour and texture under site lighting; include substrate preparation, application, cleaning and future touch-up/replacement. Artist trust does not replace an agreed sample and scope.
- Select feature-tile format early enough to coordinate finished dimensions, joints, borders, cut positions and fixture alignment. Do not stretch joints to absorb an arbitrary leftover dimension. Existing [tile selection](../subskills/interior-material-procurement/references/finish-selection-field-notes.md) governs delivered batches, pattern layout and acceptance.
- For decorative coating on glass/tile, verify the complete compatible preparation/primer/coating system and a sample. “Never cracks”, waterproof, mould-resistant or abrasion-resistant claims require actual evidence; decorative coatings do not replace wet-area membranes.
- Diatomaceous finishes: do not adopt the asserted negative-ion deodorising mechanism, whole-home humidity control or guaranteed pollutant removal. Require test method, specimen/system, conditions, durability and relevant IAQ evidence. Lack of smell is not proof of low formaldehyde or safe occupancy; use source control and appropriate ventilation/assessment.
- Reconfigurable plastic blocks may offer flexible room zoning only after stability, fixing, fire behaviour, impact/climb risk and permitted use are checked. They are not inherently child-safe, structural guards or fire/acoustic partitions. The demonstration does not authorise demolition of existing walls.
- An overlay on retained kitchen tiles needs sound/dry substrate, adhesion/fixing and junction details, actual panel-core/fire/heat performance, hob clearances and moisture/service access checks. “Aluminium composite” is not proof of a non-combustible assembly; do not bury loose tiles or active damp to save demolition cost.

## Finish quality and repairability

Sources: `KlEYVMgbRxA`, `ZFnYlgWzgQk`, `PQ-57M88Qb4`, `TiYjkUD-UhQ`, `j-htUGbRQhE`.

- Agree spray/brush/roller appearance using the named coating and a sample. Include preparation, masking/overspray controls, ventilation and matching repair method. Spray application does not automatically produce a better result, and pale colour does not guarantee invisible patching; sheen, batch, texture, lighting and ageing matter.
- For peeling paint, identify the failed layer: topcoat, filler/skim, older coating or substrate. Record damp/mould, adhesion and retained-layer condition before repair. Specify removal to a sound compatible base and moisture remediation; not every sound wall needs stripping to concrete, and painting over weak layers is not a repair. Unexpected layers require documented scope/time/cost review, not an automatic surcharge. Company reputation cannot replace inspection and system records.
- For “seamless” flooring identify actual construction/product, substrate moisture, expansion/joint and wet-use requirements. Key scratching, hammering or overnight soaking are uncontrolled demonstrations, not standard abrasion/indentation/swelling tests or warranty evidence. Do not damage installed floors to test them; use manufacturer data and, where useful, agreed sacrificial samples with recorded limitations. Dimensional recovery of a sample does not prove installed joints/core remain undamaged or waterproof.
- Detail skirting internal/external corners for actual material/profile and wall angle: mitred, scribed/coped, butt or proprietary corner as appropriate. Agree the finished sample, exposed edges, joints and price. Do not turn “all timber corners must be 45°” or “95% of tile skirting is not internally mitred” into a universal acceptance rule. Inspect completed agreed workmanship, while recording visible unresolved issues promptly.
- For 防花板 keep substrate, surface and edge process separate. A key demonstration proves neither scratch immunity nor moisture resistance of cut edges, and “no glue” does not establish zero emissions. Use [joinery evidence](../subskills/interior-millwork-technical/references/joinery-method-and-emissions.md); neither E0 dismissal nor a country-of-origin density ranking is adopted.

## Small repairs, cleaning and incomplete quizzes

Sources: `_ojov2JMMcM`, `KyuxT0v50Ow`, `lOoTFOOmJ2w`, `uYpz5rCxdpw`, `H4c47txDQxg`, `WLWzr6NKjgw`, `oiBjTceEUIU`, `qQprUwfiX2A`, `KVtmD2MalFY`, `lZ4rKe8XBrc`.

- The Dr.酷 clips often ask a question without revealing the answer. Do not invent the correct adhesive, drill bit, blade, cleaner or assembly step. Some answers would require the missing visual sequence and actual product/type. Promotions, workshop adverts and street opinions are not technical verification.
- Select residue/limescale cleaners from the actual finish and product instructions; try a discreet compatible area and protect adjacent seals/coatings. Toothpaste/eraser/solvent/vinegar or lubricant examples are not universal cleaning recipes. Do not mix unspecified cleaners or heat alcohol from a comic demonstration.
- For adhesive-only shelves, assess the wall finish's bond to its substrate as well as the adhesive, bracket geometry, load/lever arm, moisture, cure and approved temporary support. Unclear audio gives no load capacity. Do not extrapolate to grab rails or safety-critical supports; use a verified fixing/system and competent installation for those uses.
- Match driver bit, screw, torque and extension to furniture/tool instructions; “all this brand's tools fit” and “suitable for everyone” are unverified. Protect surfaces and avoid overdriving into board. A pressure-washer promotion is not a window/waterproofing test or permission to direct jets at vulnerable joints/electrics. Training/volunteering does not remove competence, consent, safe access or regulated-work requirements.

## Flood-test claims to keep qualified

Source: `yTnuyeUry04`, caption 00:13–03:11; use [water-test field checks](../subskills/interior-interface-detailing/references/water-test-field-checks.md).

Agree membrane cure, test stage, depth, duration, containment, observations and acceptance from the actual system/project requirements before programming the work. Test exposed membrane before covering and undertake specified finished-assembly tests afterwards; the latter is not “only a grout test”. Do not adopt the clip's 24/48-hour or 100 mm claims as universal BD rules, “48 hours is the highest standard”, arbitrary extra coats, unlimited soaking, guaranteed harmlessness or “every defect appears within one year”. Longer/deeper testing needs an approved method and risk review, including loads, overflow, neighbouring premises and evaporation/plug leakage. A generic one-year warranty statement does not replace the actual DLP or other applicable rights.
