# Fixtures and retained-service checks

Sources: DECO-TV batch 2; [per-file coverage and archives](../../Reference/DECO-TV-BATCH2-COVERAGE-2026-11-07.md). Summary / Transcript unless caption time is specified. Product claims and incomplete visual demonstrations are not installation instructions. Chain to MEP, procurement, interface detailing and the responsible registered trades.

## Retain or replace before enclosing

Sources: `_XJasu7qlEM`, `LwlF2ul6LmE`, `XC2PXWVIvxA`, `iy1IeMTRAII`, `0R27WsvY2pU`.

- Survey developer-supplied cabinets/appliances before ordering surrounding work: actual user needs, full hardware travel, spare-part availability, filter/grease access, ventilation and whole-unit withdrawal. Compare repair/retention with replacement and consequential making good; age, price or developer identity alone is not a reason to replace everything.
- Do not tape over appliance vents or add insect mesh without manufacturer approval of the complete airflow arrangement. The source's taped oven vent is not a remedy. Resolve pest entry and cleaning with the supplier while retaining cooling and service access.
- Define whether an inspection is visual, functional, instrumented or invasive; state qualifications, limitations and permitted opening/reinstatement. No universal claim that all inspectors only check scratches or that every new flat requires destructive investigation. Damp, powdering and blistering need measured investigation; touch alone cannot identify source or establish that a past leak is resolved.
- Coordinate accessible AC condensate routes/falls and service points before joinery/ceiling closure. Use [cooling and condensation](deco-hvac-maintenance.md) for diagnosis. A short sink demonstration with no spoken steps does not establish a complete drainage test method.
- Record supply phase and verified available capacity, appliance loads, circuits and protective arrangements with the registered electrical contractor. A three-phase board label alone does not prove spare capacity; functional outlet checks remain relevant. For repeated heater tripping, stop use and obtain competent fault investigation; do not bypass switches, protection or run a direct-to-meter feed based on the transcript.

## Shower controls and screens

Sources: `R5SRXiDxSj0`, `AEIKULAoltM`.

**Safety halt:** identify the water-heater type before choosing an on/off shower head. For a shower-type (low-pressure storage) electric water heater, do not install an outlet on/off valve or shutoff shower head. Closing the main tap afterwards does not make that incompatible installation acceptable. Use the specified unrestricted outlet arrangement and refer uncertainty to the supplier/competent installer. [EMSD electric water-heater guidance](https://www.emsd.gov.hk/en/electricity_safety/publications/guidance_notes_guidelines/safety_tips_for_using_electric_water_heaters/index.html), checked 2026-11-07, identifies excessive pressure/explosion risk. See also [compliance](compliance.md).

- For other systems, verify actual heater, hose, pressure/flow, mixer and control compatibility; never generalise the source's instruction to remove a black washer. Use specified seals/connectors. A handheld switch is not thermostatic scald protection or justification for unsupervised child bathing; evaluate accessible controls and safe temperature control separately.
- For shower screens compare framed/frameless, opening type, clear entry, swing/parking, cleaning and user reach. Measure finished openings, wall plumb, steps/columns and junctions; price extra infill panels, special geometry and finishes explicitly. Confirm safety glazing, panel size/thickness, hardware/support, waterproof penetrations and sealing with the supplier. “8 mm” in one listing and “few frameless choices” are not general design rules; clear/frosted describes appearance, not safety-glass type.

## Drainage and kitchen alterations

Sources: `3F5FM55F-Wg`, `MGk3MWk0XWs`, `Ocr9CsC0wnQ`, `DxE-6A0iFgY`, `a533fimOsxI`.

- Identify the installed trap/water seal and venting arrangement; shape labels such as U-trap and bottle trap do not establish suitability for every fixture. For washing machines, coordinate the approved waste/trap arrangement with the appliance manual and plumbing design rather than add a second trap blindly. Persistent odour needs investigation of drying, siphonage, leakage, blockage and connections. Do not generalise “1:99” to unspecified cleaners or promise that one pour cures the fault.
- A WC relocation needs a route/level survey to the soil stack, suitable falls/connections, venting and maintenance access, plus permissions. “Closer to the stack” is a coordination preference, not a verified drainage design or permission to drill a slab.
- Switching from gas to electric does not authorise removal of a kitchen enclosure. Check approved plans, structural and fire-resisting functions and the applicable approval path before alteration; retain gas-contractor requirements for gas disconnection. [BD domestic alteration FAQ](https://www.bd.gov.hk/en/resources/faq/index_alteration_and_addition_works_in_domestic_premises.html), checked 2026-11-07. For facade/common-part work, review the DMC, management requirements and statutory scope separately. Do not conceal unauthorised work beneath mosaic tiles, assume management consent is statutory approval, or infer insurance coverage from a video.

## Controls and lighting within furniture

Sources: `d8W-pxmBekw`, `e1yn-rbmxcg`, `AEgmpaRGhgU`.

- A smart power strip needs model-specific total/per-outlet limits, compatible loads, local controls and tested behaviour after network/power loss. Do not infer surge protection, energy savings or safe unattended operation from Wi-Fi/voice control. Preserve continuously required equipment; a remote-off state is not safe electrical isolation. Record account handover, control labels and support requirements.
- For USB sockets verify connector/protocol, per-port and shared output, device compatibility, back-box depth and electrical suitability. Amp labels alone do not determine charging speed. Coordinate decorative frames and modules within the manufacturer's approved system; fixed electrical work remains with registered trades.
- Compare a ceiling cove with cabinet-top/back/undershelf lighting as design alternatives. Draw the light path, glare/sightlines, task coverage, power/driver access, heat management and replaceability before cabinet manufacture. Decorative indirect light does not by itself meet task illuminance. See the lighting module and material schedule.
